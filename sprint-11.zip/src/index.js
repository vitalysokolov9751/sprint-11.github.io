import "./pages/index.css";
import "./scripts/script.js";
